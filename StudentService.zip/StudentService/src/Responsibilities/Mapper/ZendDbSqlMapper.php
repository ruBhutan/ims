<?php

namespace Responsibilities\Mapper;

use Responsibilities\Model\Responsibilities;
use Responsibilities\Model\ResponsibilityCategory;
use Responsibilities\Model\StudentResponsibility;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\Adapter\Driver\ResultInterface;
use Zend\Db\ResultSet\HydratingResultSet;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Insert;
use Zend\Db\Sql\Update;
use Zend\Db\ResultSet\ResultSet;
use Zend\Stdlib\Hydrator\HydratorInterface;

class ZendDbSqlMapper implements ResponsibilitiesMapperInterface
{
	/**
	* @var \Zend\Db\Adapter\AdapterInterface
	*
	*/
	
	protected $dbAdapter;
	
	/*
	 * @var \Zend\Stdlib\Hydrator\HydratorInterface
	*/
	protected $hydrator;
	
	/*
	 * @var \Responsibilities\Model\ResponsibilitiesInterface
	*/
	protected $responsibilityPrototype;
	
	/*
	 * @var \Responsibilities\Model\ResponsibilitiesInterface
	*/
	protected $categoryPrototype;
	
	/**
	* @param AdapterInterface $dbAdapter
	*/
	
	public function __construct(
			AdapterInterface $dbAdapter,
			HydratorInterface $hydrator,
			StudentResponsibility $categoryPrototype,
			ResponsibilityCategory $responsibilityPrototype
		)
	{
		$this->dbAdapter = $dbAdapter;
		$this->hydrator = $hydrator;
		$this->categoryPrototype = $categoryPrototype;
		$this->responsibilityPrototype = $responsibilityPrototype;
	}
	
	/*
	 * Get the Organisation Id
	 */
	 
	public function getOrganisationId($username)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		$select->from(array('t1' => 'employee_details'));
		$select->where(array('emp_id' =>$username));
		$select->columns(array('organisation_id'));
			
		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);
	}
	 
	/*
	* take username and returns employee details id
	*/
	
	public function getUserDetailsId($username, $tableName)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		$select->from(array('t1' => $tableName));
		if($tableName == 'employee_details'){
			$select->where(array('emp_id' =>$username));
		} else {
			$select->where(array('student_id' => $username));
		}
		$select->columns(array('id','organisation_id'));
			
		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);
	}

	public function getUserDetails($username, $usertype)
	{
		$name = NULL;
		
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		if($usertype == 1){
			$select->from(array('t1' => 'employee_details'));
			$select->where(array('t1.emp_id' => $username));
			$select->columns(array('first_name', 'middle_name', 'last_name'));
		}

		else if($usertype == 2){
			$select->from(array('t1' => 'student'));
			$select->where(array('student_id' => $username));
			$select->columns(array('first_name', 'middle_name', 'last_name'));
		}		
			
		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		$resultSet->initialize($result);
		
		foreach($resultSet as $set){
			$name = $set['first_name']." ".$set['middle_name']." ".$set['last_name'];
		}
		
		return $name;
	}

	public function getUserImage($username, $usertype)
	{
		$img_location = NULL;
		
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		if($usertype == 1){
			$select->from(array('t1' => 'employee_details'));
			$select->where(array('t1.emp_id' => $username));
			$select->columns(array('profile_picture', 'first_name', 'middle_name', 'last_name'));
		}

		if($usertype == 2){
			$select->from(array('t1' => 'student'));
			$select->where(array('t1.student_id' => $username));
			$select->columns(array('profile_picture', 'first_name', 'middle_name', 'last_name'));
		}		
			
		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		$resultSet->initialize($result);
		
		foreach($resultSet as $set){
			$img_location = $set['profile_picture'];
		}
		
		return $img_location;
	}
	
	/**
	* @return array/Responsibilities()
	*/
	public function findAll($tableName, $organisation_id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		if($tableName == 'responsibility_category'){
			$select->from(array('t1' => $tableName));
			$select->where(array('t1.organisation_id' =>$organisation_id));
		}
		else if($tableName == 'student')
		{
			$select->from(array('t1' => $tableName));
			$select->where(array('t1.organisation_id' =>$organisation_id));
		}
		else if($tableName == 'student_responsibilities'){
			$select->from(array('t1' => $tableName))
			       ->join(array('t2' => 'student'),
			   			't2.id = t1.student_id', array('first_name', 'middle_name', 'last_name', 'student_id'))
			       ->join(array('t3' => 'responsibility_category'),
			   			't3.id = t1.responsibility_category_id', array('responsibility_name', 'responsibility_description'));
			$select->where(array('t2.organisation_id' => $organisation_id));
		}

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);

	}
        
	/**
	 * 
	 * @param type $ResponsibilitiesInterface
	 * 
	 * to save Vision and Mission Details
	 */
	
	public function saveCategory(ResponsibilityCategory $responsibilityObject)
	{
		$responsibilityData = $this->hydrator->extract($responsibilityObject);
		unset($responsibilityData['id']);
		
		if($responsibilityObject->getId()) {
			//ID present, so it is an update
			$action = new Update('responsibility_category');
			$action->set($responsibilityData);
			$action->where(array('id = ?' => $responsibilityObject->getId()));
		} else {
			//ID is not present, so its an insert
			$action = new Insert('responsibility_category');
			$action->values($responsibilityData);
		}
		
		$sql = new Sql($this->dbAdapter);
		$stmt = $sql->prepareStatementForSqlObject($action);
		$result = $stmt->execute();

		
		if($result instanceof ResultInterface) {
			if($newId = $result->getGeneratedValue()){
				//when a value has been generated, set it on the object
				echo $responsibilityObject->setId($newId);
			}
			return $responsibilityObject;
		}
		
		throw new \Exception("Database Error");
	}
	
	
	/**
	 * 
	 * @param type $ResponsibilitiesInterface
	 * 
	 * to save Objectives Details
	 */
	
	public function saveResponsibility(StudentResponsibility $responsibilityObject)
	{
		$responsibilityData = $this->hydrator->extract($responsibilityObject);
		unset($responsibilityData['id']);
                
                //need to get the file locations and store them in database
		$evidence_file_name = $responsibilityData['evidence_File'];
		$responsibilityData['evidence_File'] = $evidence_file_name['tmp_name'];

		$responsibilityData['start_Date'] = date("Y-m-d", strtotime(substr($responsibilityData['start_Date'],0,10)));
		$responsibilityData['end_Date'] = date("Y-m-d", strtotime(substr($responsibilityData['end_Date'],0,10)));

		if($responsibilityObject->getId()) {
			//ID present, so it is an update
			$action = new Update('student_responsibilities');
			$action->set($responsibilityData);
			$action->where(array('id = ?' => $responsibilityObject->getId()));
		} else {
			//ID is not present, so its an insert
			$action = new Insert('student_responsibilities');
			$action->values($responsibilityData);
		}
		
		$sql = new Sql($this->dbAdapter);
		$stmt = $sql->prepareStatementForSqlObject($action);
		$result = $stmt->execute();

		
		if($result instanceof ResultInterface) {
			if($newId = $result->getGeneratedValue()){
				//when a value has been generated, set it on the object
				echo $responsibilityObject->setId($newId);
			}
			return $responsibilityObject;
		}
		
		throw new \Exception("Database Error");
	}



	public function updateResponsibility(StudentResponsibility $responsibilityObject)
	{
		$responsibilityData = $this->hydrator->extract($responsibilityObject);
		unset($responsibilityData['id']);
               

		$responsibilityData['start_Date'] = date("Y-m-d", strtotime(substr($responsibilityData['start_Date'],0,10)));
		$responsibilityData['end_Date'] = date("Y-m-d", strtotime(substr($responsibilityData['end_Date'],0,10)));
		
		if($responsibilityObject->getId()) {
			//ID present, so it is an update
			$action = new Update('student_responsibilities');
			$action->set($responsibilityData);
			$action->where(array('id = ?' => $responsibilityObject->getId()));
		} else {
			//ID is not present, so its an insert
			$action = new Insert('student_responsibilities');
			$action->values($responsibilityData);
		}
		
		$sql = new Sql($this->dbAdapter);
		$stmt = $sql->prepareStatementForSqlObject($action);
		$result = $stmt->execute();

		
		if($result instanceof ResultInterface) {
			if($newId = $result->getGeneratedValue()){
				//when a value has been generated, set it on the object
				echo $responsibilityObject->setId($newId);
			}
			return $responsibilityObject;
		}
		
		throw new \Exception("Database Error");
	}
	
	/**
	 * 
	 * @param type $id
	 * 
	 * to find Responsibility Category details to edit/display
	 */
	 
	 public function getResponsibilityCategoryDetails($id) 
	 {
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		$select->from(array('t1' => 'responsibility_category')) // base table
				->where('t1.id = ' .$id); // join expression

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);
	 }
	
	/*
	* List Student to add awards etc
	*/
	
	public function getStudentList($studentName, $studentId, $programme, $organisation_id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();
		
		$select->from(array('t1' => 'student'))
				->join(array('t2' => 'programmes'), 
                            't1.programmes_id = t2.id', array('programme_name'));
		
		if($studentName){
			$select->where->like('first_name','%'.$studentName.'%');
		}
		if($studentId){
			$select->where(array('student_id' =>$studentId));
		}
		if($programme){
			$select->where(array('programme' =>$programme));
		}
		if($organisation_id){
			$select->where(array('t1.organisation_id' =>$organisation_id));
		}

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result); 

	}
	
	/*
	* Get the list of responsibilities by students after search funcationality
	*/
	
	public function getStudentResponsibilitiesList($studentName, $studentId, $programme, $organisation_id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();
		
		$select->from(array('t1' => 'student_responsibilities'))
					->columns(array('id', 'start_date','end_date','remarks'))
                    ->join(array('t4'=>'responsibility_category'),
                            't1.responsibility_category_id = t4.id', array('responsibility_name'))
					->join(array('t2' => 'student'), 
                            't1.student_id = t2.id', array('first_name','middle_name','last_name','student_id','enrollment_year'))
					->join(array('t3' => 'programmes'), 
                            't2.programmes_id = t3.id', array('programme_name'));					
		if($studentName){
			$select->where->like('t2.first_name','%'.$studentName.'%');
		}
		if($studentId){
			$select->where(array('t2.student_id' =>$studentId));
		}
		if($programme){
			$select->where(array('t2.programme' =>$programme));
		}
		if($organisation_id){
			$select->where(array('t2.organisation_id' =>$organisation_id));
		}

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result); 
	}
	
	/*
	 * List Student with their responsibilities
	 */
	
	public function listStudentResponsibilities($organisation_id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();
		
		$select->from(array('t1' => 'student_responsibilities')) 
                    ->columns(array('id', 'start_date','end_date','remarks'))
					->join(array('t2' => 'student'), 
                            't1.student_id = t2.id', array('first_name','middle_name','last_name','student_id','enrollment_year'))
                    ->join(array('t3'=>'responsibility_category'),
                            't1.responsibility_category_id = t3.id', array('responsibility_name'))
                   ->where(array('t2.organisation_id' =>$organisation_id));

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);	
	}
	
	/*
	* Get the list of responsibilities by a student
	*/
	
	public function getStudentResponsibilities($id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();
		
		$select->from(array('t1' => 'student_responsibilities'))
					 ->columns(array('id', 'start_date','end_date','remarks', 'responsibility_category_id', 'evidence_file', 'student_id'))
                    ->join(array('t2' => 'student'), 
                            't1.student_id = t2.id', array('first_name','middle_name','last_name','studentId'=>'student_id','enrollment_year'))
					->join(array('t3' => 'programmes'), 
                            't2.programmes_id = t3.id', array('programme_name'))
					->join(array('t4'=>'responsibility_category'),
                            't1.responsibility_category_id = t4.id', array('responsibility_name'));
		$select->where(array('t1.id' =>$id));

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result); 
	}
	
	/**
	 * 
	 * @param type $id
	 * 
	 * to find Student details so that their names are displayed
	 */
	public function getStudentDetails($id) 
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();
		$select->from(array('t1' => 'student')) // base table
				->where('t1.id = ' .$id); // join expression
		
		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		return $resultSet->initialize($result);
		
	}
	
	
	/**
	* @return array/Responsibilities()
	* The following function is for listing data for select/dropdown form
	* For e.g. Need to fill the objectives field with Objectives from the database
	*/
	public function listSelectData($tableName, $columnName, $organisation_id)
	{
		$sql = new Sql($this->dbAdapter);
		$select = $sql->select();

		$select->from(array('t1' => $tableName));
		$select->columns(array('id',$columnName));
		$select->where(array('t1.organisation_id' =>$organisation_id));

		$stmt = $sql->prepareStatementForSqlObject($select);
		$result = $stmt->execute();
		
		$resultSet = new ResultSet();
		$resultSet->initialize($result);
		
		//Need to make the resultSet as an array
		// e.g. 1=> Objective 1, 2 => Objective etc.
		
		$selectData = array();
		foreach($resultSet as $set)
		{
			$selectData[$set['id']] = $set[$columnName];
		}
		return $selectData;
			
	}
        
}